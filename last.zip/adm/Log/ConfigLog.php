
El usuario  cambio la siguiente configuraci�n:
�Servidor cerrado? : 
�Modo DEBUG activado? : 
Nombre del juego : XG Proyect
URL del foro : http://www.xgproyect.net/
An easter egg!Velocidad del juego : x100
Velocidad de flota : x100
Velocidad de producci�n : x100
Campos iniciales : 163
B�sico de metal por hora : 20
B�sico de cristal por hora : 10
B�sico de deuterio por hora : 0
: 0
�Protecci�n contra administradores activado? : 
Lenguaje : spanish
Nombre de la cookie : XGProyect
Defensas a escombros : 30%
Naves a escombros : 30%
�Protecci�n contra novatos activado? : 
Tiempo de protecci�n contra novato : 5000
Limite de puntos para la protecci�n de novato : 5
Operaci�n realizada el: 15-11-2010 17:09:54
