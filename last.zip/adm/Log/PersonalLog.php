
El usuario lucky modifico los siguientes datos:
al usuario con el ID: 1
Operaci�n realizada el: 25-02-2010 19:49:01
