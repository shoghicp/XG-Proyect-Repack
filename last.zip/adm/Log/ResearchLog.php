
El usuario shoghicp agrego:
Tecnolog�a de espionaje: 0
Tecnolog�a de computaci�n: 0
Tecnolog�a militar: 0
Tecnolog�a de defensa: 0
Tecnolog�a de blindaje: 0
Tecnolog�a de energ�a: 0
Tecnolog�a de hiperespacio: 0
Motor de combusti�n: 0
Motor de impulso: 0
Propulsor hiperespacial: 0
Tecnolog�a l�ser: 0
Tecnolog�a i�nica: 0
Tecnolog�a de plasma: 0
Red de investigaci�n intergal�ctica: 0
Tecnolog�a de expedicion: 6
Tecnolog�a de gravit�n: 0
al usuario con el ID: 1
Operaci�n realizada el: 26-10-2010 16:20:07
