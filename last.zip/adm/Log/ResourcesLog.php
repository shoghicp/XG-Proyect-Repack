
El usuario shoghicp agrego:
Metal: 10000
Cristal: 10000
Deuterio: 10000
Tritio: 0
al planeta con el ID: 1
y Materia oscura: 0
al usuario con el ID: 0
Operaci�n realizada el: 26-10-2010 16:24:19
:33
9:19:54
