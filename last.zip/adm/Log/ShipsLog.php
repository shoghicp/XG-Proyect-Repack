
El usuario shoghicp agrego:
Nave peque�a de carga: 0
Nave grande de carga: 0
Cazador ligero: 0
Cazador pesado: 0
Crucero: 0
Nave de batalla: 0
Colonizador: 0
Reciclador: 100
Sonda de espionaje: 0
Bombardero: 0
Sat�lite solar: 0
Destructor: 0
Estrella de la muerte: 0
Acorazado: 0
Supernova: 0
al planeta con el ID: 1
Operaci�n realizada el: 26-10-2010 16:24:48
18:33
 19:59:41
 el: 27-02-2010 15:25:06
