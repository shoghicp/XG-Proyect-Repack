<?php
	define('VERSION', 'XGrp4');
	define('XG_BASED', '2.9.7');
?>
